//Justin Harris 
//CS445
//Last Updated: 3-12-22

#ifndef IOINIT_H
#define IOINIT_H

void setupIO();

#endif