#ifndef IOINIT_H
#define IOINIT_H

void setupIO();

#endif